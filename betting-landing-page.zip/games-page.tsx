"use client"

import { useState } from "react"
import { Menu, X, Star, Twitter, Instagram } from "lucide-react"
import Link from "next/link"

// Game data type
interface Game {
  id: number
  title: string
  category: string
  rating: number
  isNew: boolean
  isHot: boolean
  image: string
  link: string
}

export default function GamesPage() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  // Sample game data
  const games: Game[] = [
    {
      id: 1,
      title: "Memory Game",
      category: "skill",
      rating: 4.8,
      isNew: true,
      isHot: true,
      image: "/placeholder.svg?height=300&width=400",
      link: "/memory-game",
    },
    {
      id: 2,
      title: "Cyber Blackjack",
      category: "table",
      rating: 4.5,
      isNew: false,
      isHot: false,
      image: "/placeholder.svg?height=300&width=400",
      link: "#",
    },
    {
      id: 3,
      title: "Sensual Roulette Live",
      category: "live",
      rating: 4.9,
      isNew: false,
      isHot: true,
      image: "/placeholder.svg?height=300&width=400",
      link: "#",
    },
    {
      id: 5,
      title: "Cosmic Spins",
      category: "slots",
      rating: 4.3,
      isNew: true,
      isHot: false,
      image: "/placeholder.svg?height=300&width=400",
      link: "#",
    },
    {
      id: 8,
      title: "Cyber Craps",
      category: "table",
      rating: 4.2,
      isNew: true,
      isHot: false,
      image: "/placeholder.svg?height=300&width=400",
      link: "#",
    },
    {
      id: 12,
      title: "Live Sensual Poker",
      category: "live",
      rating: 4.9,
      isNew: false,
      isHot: true,
      image: "/placeholder.svg?height=300&width=400",
      link: "#",
    },
  ]

  return (
    <div className="min-h-screen bg-black text-white font-['Quicksand']">
      {/* Header */}
      <header className="bg-black sticky top-0 z-50 shadow-md border-b border-[#7fdbff] border-opacity-30">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="text-2xl md:text-3xl font-['Quicksand'] text-white font-bold relative">
            <Link href="/">
              <span className="text-[#f08bf0] drop-shadow-[0_0_8px_rgba(240,139,240,0.6)]">Boo</span>
              <span className="text-[#7fdbff] drop-shadow-[0_0_8px_rgba(127,219,255,0.6)]">Bets</span>
              <div className="absolute -bottom-1 left-0 w-full h-[2px] bg-gradient-to-r from-[#f08bf0] to-[#7fdbff]"></div>
            </Link>
          </div>

          {/* Mobile menu button */}
          <button className="md:hidden text-white" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X size={24} className="text-[#7fdbff]" /> : <Menu size={24} className="text-[#7fdbff]" />}
          </button>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/" className="text-white hover:text-[#7fdbff] transition-colors duration-300 relative group">
              Home
              <span className="absolute -bottom-1 left-0 w-0 h-[2px] bg-[#7fdbff] group-hover:w-full transition-all duration-300"></span>
            </Link>
            <Link href="#" className="text-[#7fdbff] transition-colors duration-300 relative group">
              Games
              <span className="absolute -bottom-1 left-0 w-full h-[2px] bg-[#7fdbff] transition-all duration-300"></span>
            </Link>
            <Link href="#" className="text-white hover:text-[#7fdbff] transition-colors duration-300 relative group">
              Content
              <span className="absolute -bottom-1 left-0 w-0 h-[2px] bg-[#7fdbff] group-hover:w-full transition-all duration-300"></span>
            </Link>
            <Link href="#" className="text-white hover:text-[#7fdbff] transition-colors duration-300 relative group">
              Register
              <span className="absolute -bottom-1 left-0 w-0 h-[2px] bg-[#7fdbff] group-hover:w-full transition-all duration-300"></span>
            </Link>
            <Link href="#" className="text-white hover:text-[#7fdbff] transition-colors duration-300 relative group">
              Login
              <span className="absolute -bottom-1 left-0 w-0 h-[2px] bg-[#7fdbff] group-hover:w-full transition-all duration-300"></span>
            </Link>
            <button className="bg-[#f08bf0] hover:bg-[#f08bf0]/80 text-white px-4 py-2 rounded-full transition-all duration-300 hover:scale-105 shadow-[0_0_15px_rgba(240,139,240,0.4)] hover:shadow-[0_0_20px_rgba(240,139,240,0.5)]">
              Join Now
            </button>
          </nav>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden bg-black py-4 px-4 absolute w-full border-b border-[#7fdbff] border-opacity-30">
            <nav className="flex flex-col space-y-4">
              <Link href="/" className="text-white hover:text-[#7fdbff] transition-colors duration-300">
                Home
              </Link>
              <Link href="#" className="text-[#7fdbff] transition-colors duration-300">
                Games
              </Link>
              <Link href="#" className="text-white hover:text-[#7fdbff] transition-colors duration-300">
                Content
              </Link>
              <Link href="#" className="text-white hover:text-[#7fdbff] transition-colors duration-300">
                Register
              </Link>
              <Link href="#" className="text-white hover:text-[#7fdbff] transition-colors duration-300">
                Login
              </Link>
              <button className="bg-[#f08bf0] hover:bg-[#f08bf0]/80 text-white px-4 py-2 rounded-full transition-transform duration-300 hover:scale-105 w-full shadow-[0_0_15px_rgba(240,139,240,0.4)]">
                Join Now
              </button>
            </nav>
          </div>
        )}
      </header>

      {/* Games Hero Section */}
      <section className="relative py-12 bg-black overflow-hidden border-b border-[#7fdbff] border-opacity-20">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxwYXR0ZXJuIGlkPSJncmlkIiB3aWR0aD0iODAiIGhlaWdodD0iODAiIHBhdHRlcm5Vbml0cz0idXNlclNwYWNlT25Vc2UiPjxwYXRoIGQ9Ik0gODAgMCBMIDAgMCAwIDgwIiBmaWxsPSJub25lIiBzdHJva2U9IiMwZmYiIHN0cm9rZS13aWR0aD0iMC41IiBzdHJva2Utb3BhY2l0eT0iMC4xIi8+PC9wYXR0ZXJuPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZ3JpZCkiLz48L3N2Zz4=')] opacity-30"></div>

        {/* Animated circles */}
        <div className="absolute -bottom-20 -left-20 w-60 h-60 bg-[#f08bf0] rounded-full filter blur-[100px] opacity-20 animate-pulse"></div>
        <div
          className="absolute -top-20 -right-20 w-60 h-60 bg-[#7fdbff] rounded-full filter blur-[100px] opacity-20 animate-pulse"
          style={{ animationDelay: "1s" }}
        ></div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-8">
            <h1 className="text-3xl md:text-5xl font-bold mb-4">
              <span className="text-[#7fdbff] drop-shadow-[0_0_8px_rgba(127,219,255,0.6)]">Explore</span> Our{" "}
              <span className="text-[#f08bf0] drop-shadow-[0_0_8px_rgba(240,139,240,0.6)]">Games</span>
            </h1>
            <p className="text-lg text-gray-300 max-w-2xl mx-auto">
              Discover our exclusive collection of games, from thrilling slots to immersive live casino experiences
            </p>
          </div>
        </div>
      </section>

      {/* Games Grid */}
      <section className="py-12 bg-black">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {games.map((game) => (
              <div
                key={game.id}
                className="group relative bg-black border border-gray-800 rounded-lg overflow-hidden transition-all duration-300 hover:scale-[1.02] hover:shadow-[0_0_20px_rgba(127,219,255,0.2)] hover:border-[#7fdbff]"
              >
                <div className="relative aspect-[4/3] overflow-hidden">
                  <img
                    src={game.image || "/placeholder.svg"}
                    alt={game.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-60"></div>

                  {/* Game badges */}
                  <div className="absolute top-2 left-2 flex gap-2">
                    {game.isNew && (
                      <span className="bg-[#7fdbff] text-black text-xs font-bold px-2 py-1 rounded-full">NEW</span>
                    )}
                    {game.isHot && (
                      <span className="bg-[#f08bf0] text-black text-xs font-bold px-2 py-1 rounded-full">HOT</span>
                    )}
                  </div>

                  {/* Play button overlay */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <Link href={game.link}>
                      <button className="bg-[#f08bf0] hover:bg-[#f08bf0]/90 text-white px-6 py-2 rounded-full font-bold transition-all duration-300 hover:scale-105 shadow-[0_0_15px_rgba(240,139,240,0.6)]">
                        Play Now
                      </button>
                    </Link>
                  </div>
                </div>

                <div className="p-4">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-lg font-bold text-white group-hover:text-[#7fdbff] transition-colors duration-300">
                      {game.title}
                    </h3>
                    <div className="flex items-center">
                      <Star className="text-[#f08bf0] fill-[#f08bf0]" size={14} />
                      <span className="text-sm ml-1">{game.rating}</span>
                    </div>
                  </div>
                  <p className="text-sm text-gray-400 capitalize">
                    {game.category === "live"
                      ? "Live Casino"
                      : game.category === "table"
                        ? "Table Game"
                        : game.category === "slots"
                          ? "Slots"
                          : game.category === "skill"
                            ? "Skill Game"
                            : game.category}
                  </p>
                </div>

                {/* Neon border effect on hover */}
                <div className="absolute inset-0 pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="absolute inset-0 border border-[#7fdbff] rounded-lg shadow-[0_0_10px_rgba(127,219,255,0.3),inset_0_0_10px_rgba(127,219,255,0.2)]"></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 bg-black relative overflow-hidden border-t border-[#7fdbff] border-opacity-20">
        <div className="absolute inset-0 bg-gradient-to-r from-[#f08bf0]/10 to-[#7fdbff]/10"></div>

        <div className="container mx-auto px-4 text-center relative z-10">
          <h2 className="text-2xl md:text-3xl font-bold mb-4">
            Ready to <span className="text-[#7fdbff] drop-shadow-[0_0_10px_rgba(127,219,255,0.4)]">play</span> and{" "}
            <span className="text-[#f08bf0] drop-shadow-[0_0_10px_rgba(240,139,240,0.4)]">win</span>?
          </h2>
          <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
            Join now to get exclusive bonuses and start playing your favorite games
          </p>
          <button className="bg-[#f08bf0] hover:bg-[#f08bf0]/80 text-white px-6 py-3 rounded-full font-bold transition-all duration-300 hover:scale-105 shadow-[0_0_15px_rgba(240,139,240,0.4)] hover:shadow-[0_0_20px_rgba(240,139,240,0.5)]">
            Create Account
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black py-8 border-t border-[#7fdbff] border-opacity-30">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="text-xl font-['Quicksand'] font-bold mb-4 md:mb-0 relative">
              <span className="text-[#f08bf0] drop-shadow-[0_0_8px_rgba(240,139,240,0.6)]">Boo</span>
              <span className="text-[#7fdbff] drop-shadow-[0_0_8px_rgba(127,219,255,0.6)]">Bets</span>
              <div className="absolute -bottom-1 left-0 w-full h-[2px] bg-gradient-to-r from-[#f08bf0] to-[#7fdbff]"></div>
            </div>
            <div className="flex space-x-6 mb-4 md:mb-0">
              <Link
                href="#"
                className="text-gray-400 hover:text-[#7fdbff] transition-colors duration-300 relative group"
              >
                Terms
                <span className="absolute -bottom-1 left-0 w-0 h-[1px] bg-[#7fdbff] group-hover:w-full transition-all duration-300"></span>
              </Link>
              <Link
                href="#"
                className="text-gray-400 hover:text-[#7fdbff] transition-colors duration-300 relative group"
              >
                Privacy
                <span className="absolute -bottom-1 left-0 w-0 h-[1px] bg-[#7fdbff] group-hover:w-full transition-all duration-300"></span>
              </Link>
              <Link
                href="#"
                className="text-gray-400 hover:text-[#7fdbff] transition-colors duration-300 relative group"
              >
                Contact
                <span className="absolute -bottom-1 left-0 w-0 h-[1px] bg-[#7fdbff] group-hover:w-full transition-all duration-300"></span>
              </Link>
            </div>
            <div className="flex space-x-4">
              <Link
                href="#"
                className="text-gray-400 hover:text-[#7fdbff] transition-all duration-300 transform hover:scale-110"
              >
                <Twitter size={20} className="hover:drop-shadow-[0_0_8px_rgba(127,219,255,0.6)]" />
              </Link>
              <Link
                href="#"
                className="text-gray-400 hover:text-[#f08bf0] transition-all duration-300 transform hover:scale-110"
              >
                <Instagram size={20} className="hover:drop-shadow-[0_0_8px_rgba(240,139,240,0.6)]" />
              </Link>
            </div>
          </div>
          <div className="mt-8 text-center text-gray-500 text-sm">
            &copy; {new Date().getFullYear()} BooBets. All rights reserved. For adults 18+ only.
          </div>
        </div>
      </footer>
    </div>
  )
}

