"use client"

import { useState, useEffect } from "react"
import { Menu, X, Star, Twitter, Instagram, Zap, Trophy } from "lucide-react"
import Link from "next/link"

export default function LandingPage() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    setIsVisible(true)
  }, [])

  return (
    <div className="min-h-screen bg-black text-white font-['Quicksand']">
      {/* Header */}
      <header className="bg-black sticky top-0 z-50 shadow-md border-b border-[#0ff] border-opacity-30">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="text-2xl md:text-3xl font-['Quicksand'] text-white font-bold relative">
            <span className="text-[#f08bf0] drop-shadow-[0_0_8px_rgba(240,139,240,0.6)]">Boo</span>
            <span className="text-[#7fdbff] drop-shadow-[0_0_8px_rgba(127,219,255,0.6)]">Bets</span>
            <div className="absolute -bottom-1 left-0 w-full h-[2px] bg-gradient-to-r from-[#f08bf0] to-[#7fdbff]"></div>
          </div>

          {/* Mobile menu button */}
          <button className="md:hidden text-white" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X size={24} className="text-[#7fdbff]" /> : <Menu size={24} className="text-[#7fdbff]" />}
          </button>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="#" className="text-white hover:text-[#7fdbff] transition-colors duration-300 relative group">
              Home
              <span className="absolute -bottom-1 left-0 w-0 h-[2px] bg-[#0ff] group-hover:w-full transition-all duration-300"></span>
            </Link>
            <Link
              href="/games"
              className="text-white hover:text-[#7fdbff] transition-colors duration-300 relative group"
            >
              Games
              <span className="absolute -bottom-1 left-0 w-0 h-[2px] bg-[#0ff] group-hover:w-full transition-all duration-300"></span>
            </Link>
            <Link href="#" className="text-white hover:text-[#7fdbff] transition-colors duration-300 relative group">
              Content
              <span className="absolute -bottom-1 left-0 w-0 h-[2px] bg-[#0ff] group-hover:w-full transition-all duration-300"></span>
            </Link>
            <Link href="#" className="text-white hover:text-[#7fdbff] transition-colors duration-300 relative group">
              Register
              <span className="absolute -bottom-1 left-0 w-0 h-[2px] bg-[#0ff] group-hover:w-full transition-all duration-300"></span>
            </Link>
            <Link href="#" className="text-white hover:text-[#7fdbff] transition-colors duration-300 relative group">
              Login
              <span className="absolute -bottom-1 left-0 w-0 h-[2px] bg-[#0ff] group-hover:w-full transition-all duration-300"></span>
            </Link>
            <Link href="/auth">
              <button className="bg-[#f08bf0] hover:bg-[#f08bf0]/80 text-white px-4 py-2 rounded-full transition-all duration-300 hover:scale-105 shadow-[0_0_15px_rgba(240,139,240,0.4)] hover:shadow-[0_0_20px_rgba(240,139,240,0.5)]">
                Join Now
              </button>
            </Link>
          </nav>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden bg-black py-4 px-4 absolute w-full border-b border-[#0ff] border-opacity-30">
            <nav className="flex flex-col space-y-4">
              <Link href="#" className="text-white hover:text-[#0ff] transition-colors duration-300">
                Home
              </Link>
              <Link href="/games" className="text-white hover:text-[#0ff] transition-colors duration-300">
                Games
              </Link>
              <Link href="#" className="text-white hover:text-[#0ff] transition-colors duration-300">
                Content
              </Link>
              <Link href="#" className="text-white hover:text-[#0ff] transition-colors duration-300">
                Register
              </Link>
              <Link href="#" className="text-white hover:text-[#0ff] transition-colors duration-300">
                Login
              </Link>
              <Link href="/auth" className="w-full">
                <button className="bg-[#f08bf0] hover:bg-[#f08bf0]/80 text-white px-4 py-2 rounded-full transition-transform duration-300 hover:scale-105 w-full shadow-[0_0_15px_rgba(240,139,240,0.4)]">
                  Join Now
                </button>
              </Link>
            </nav>
          </div>
        )}
      </header>

      {/* Hero Section */}
      <section
        className="relative bg-cover bg-center h-[80vh] flex items-center overflow-hidden"
        style={{
          backgroundImage: "url('/placeholder.svg?height=1080&width=1920')",
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <div className="absolute inset-0 bg-black bg-opacity-80"></div>

        {/* Neon grid lines */}
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxwYXR0ZXJuIGlkPSJncmlkIiB3aWR0aD0iODAiIGhlaWdodD0iODAiIHBhdHRlcm5Vbml0cz0idXNlclNwYWNlT25Vc2UiPjxwYXRoIGQ9Ik0gODAgMCBMIDAgMCAwIDgwIiBmaWxsPSJub25lIiBzdHJva2U9IiMwZmYiIHN0cm9rZS13aWR0aD0iMC41IiBzdHJva2Utb3BhY2l0eT0iMC4xIi8+PC9wYXR0ZXJuPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZ3JpZCkiLz48L3N2Zz4=')] opacity-30"></div>
        </div>

        {/* Animated circles */}
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-[#ff00ff] rounded-full filter blur-[100px] opacity-20 animate-pulse"></div>
        <div
          className="absolute -top-40 -right-40 w-80 h-80 bg-[#0ff] rounded-full filter blur-[100px] opacity-20 animate-pulse"
          style={{ animationDelay: "1s" }}
        ></div>

        <div
          className={`container mx-auto px-4 z-10 transition-opacity duration-1000 ${isVisible ? "opacity-100" : "opacity-0"}`}
        >
          <h1 className="text-4xl md:text-6xl font-['Quicksand'] font-bold mb-4 max-w-3xl text-white drop-shadow-[0_0_10px_rgba(255,255,255,0.4)]">
            <span className="text-[#7fdbff] drop-shadow-[0_0_10px_rgba(127,219,255,0.6)]">Bet</span> with Passion,
            <span className="text-[#f08bf0] drop-shadow-[0_0_10px_rgba(240,139,240,0.6)]"> Live</span> the Excitement
          </h1>
          <p className="text-xl md:text-2xl mb-8 max-w-2xl text-white">
            Discover a unique betting experience with exclusive entertainment
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <button className="bg-[#f08bf0] hover:bg-[#f08bf0]/80 text-white px-6 py-3 rounded-full font-bold transition-all duration-300 hover:scale-105 shadow-[0_0_15px_rgba(240,139,240,0.4)] hover:shadow-[0_0_20px_rgba(240,139,240,0.5)]">
              Register Free
            </button>
            <Link href="/games">
              <button className="bg-transparent border-2 border-[#7fdbff] text-[#7fdbff] px-6 py-3 rounded-full font-bold transition-all duration-300 hover:scale-105 hover:bg-[#7fdbff]/10 shadow-[0_0_15px_rgba(127,219,255,0.2)] hover:shadow-[0_0_20px_rgba(127,219,255,0.3)]">
                Explore Games
              </button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-black relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxwYXR0ZXJuIGlkPSJncmlkIiB3aWR0aD0iODAiIGhlaWdodD0iODAiIHBhdHRlcm5Vbml0cz0idXNlclNwYWNlT25Vc2UiPjxwYXRoIGQ9Ik0gODAgMCBMIDAgMCAwIDgwIiBmaWxsPSJub25lIiBzdHJva2U9IiMwZmYiIHN0cm9rZS13aWR0aD0iMC41IiBzdHJva2Utb3BhY2l0eT0iMC4xIi8+PC9wYXR0ZXJuPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZ3JpZCkiLz48L3N2Zz4=')] opacity-30"></div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="bg-black p-8 rounded-lg border border-[#7fdbff] border-opacity-30 transition-all duration-300 hover:scale-105 hover:shadow-[0_0_20px_rgba(127,219,255,0.2)] group">
              <div className="bg-black w-16 h-16 rounded-full flex items-center justify-center mb-6 border border-[#7fdbff] group-hover:shadow-[0_0_15px_rgba(127,219,255,0.4)] transition-all duration-300">
                <Zap className="text-[#7fdbff]" size={28} />
              </div>
              <h3 className="text-xl font-['Quicksand'] font-bold mb-4 text-[#7fdbff]">Live Betting</h3>
              <p className="text-gray-300">Play in real-time with the best odds and exciting matches</p>
            </div>

            {/* Feature 2 */}
            <div className="bg-black p-8 rounded-lg border border-[#f08bf0] border-opacity-30 transition-all duration-300 hover:scale-105 hover:shadow-[0_0_20px_rgba(240,139,240,0.2)] group">
              <div className="bg-black w-16 h-16 rounded-full flex items-center justify-center mb-6 border border-[#f08bf0] group-hover:shadow-[0_0_15px_rgba(240,139,240,0.4)] transition-all duration-300">
                <Star className="text-[#f08bf0]" size={28} />
              </div>
              <h3 className="text-xl font-['Quicksand'] font-bold mb-4 text-[#f08bf0]">Exclusive Content</h3>
              <p className="text-gray-300">Access to sensual material for members only</p>
            </div>

            {/* Feature 3 */}
            <div className="bg-black p-8 rounded-lg border border-[#7fdbff] border-opacity-30 transition-all duration-300 hover:scale-105 hover:shadow-[0_0_20px_rgba(127,219,255,0.2)] group">
              <div className="bg-black w-16 h-16 rounded-full flex items-center justify-center mb-6 border border-[#7fdbff] group-hover:shadow-[0_0_15px_rgba(127,219,255,0.4)] transition-all duration-300">
                <Trophy className="text-[#7fdbff]" size={28} />
              </div>
              <h3 className="text-xl font-['Quicksand'] font-bold mb-4 text-[#7fdbff]">Fast Withdrawals</h3>
              <p className="text-gray-300">Get your winnings instantly with our secure payment system</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-black relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-[#f08bf0]/15 to-[#7fdbff]/15"></div>
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxwYXR0ZXJuIGlkPSJncmlkIiB3aWR0aD0iODAiIGhlaWdodD0iODAiIHBhdHRlcm5Vbml0cz0idXNlclNwYWNlT25Vc2UiPjxwYXRoIGQ9Ik0gODAgMCBMIDAgMCAwIDgwIiBmaWxsPSJub25lIiBzdHJva2U9IiMwZmYiIHN0cm9rZS13aWR0aD0iMC41IiBzdHJva2Utb3BhY2l0eT0iMC4xIi8+PC9wYXR0ZXJuPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZ3JpZCkiLz48L3N2Zz4=')] opacity-30"></div>

        <div className="container mx-auto px-4 text-center relative z-10">
          <h2 className="text-3xl md:text-4xl font-['Quicksand'] font-bold mb-6 text-white">
            Ready to <span className="text-[#7fdbff] drop-shadow-[0_0_10px_rgba(127,219,255,0.4)]">win</span> and{" "}
            <span className="text-[#f08bf0] drop-shadow-[0_0_10px_rgba(240,139,240,0.4)]">enjoy</span>? Join today
          </h2>
          <div className="relative inline-block">
            <Link href="/auth?mode=register">
              <button className="bg-[#f08bf0] hover:bg-[#f08bf0]/80 text-white px-8 py-4 rounded-full font-bold text-xl transition-all duration-300 hover:scale-105 relative z-10 shadow-[0_0_15px_rgba(240,139,240,0.4)] hover:shadow-[0_0_25px_rgba(240,139,240,0.5)]">
                Create Your Account
              </button>
            </Link>
            <div className="absolute -inset-1 bg-gradient-to-r from-[#7fdbff] to-[#f08bf0] rounded-full blur opacity-50 z-0 animate-pulse"></div>
          </div>

          {/* Fun element - floating emojis */}
          <div className="mt-12 relative h-20">
            <div className="absolute left-1/4 animate-bounce" style={{ animationDuration: "2s" }}>
              <span className="text-3xl">🎮</span>
            </div>
            <div
              className="absolute left-1/3 animate-bounce"
              style={{ animationDuration: "2.5s", animationDelay: "0.5s" }}
            >
              <span className="text-3xl">💋</span>
            </div>
            <div
              className="absolute left-1/2 animate-bounce"
              style={{ animationDuration: "1.8s", animationDelay: "0.3s" }}
            >
              <span className="text-3xl">🎲</span>
            </div>
            <div
              className="absolute left-2/3 animate-bounce"
              style={{ animationDuration: "2.2s", animationDelay: "0.7s" }}
            >
              <span className="text-3xl">💰</span>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black py-8 border-t border-[#0ff] border-opacity-30">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="text-xl font-['Quicksand'] font-bold mb-4 md:mb-0 relative">
              <span className="text-[#f08bf0] drop-shadow-[0_0_8px_rgba(240,139,240,0.6)]">Boo</span>
              <span className="text-[#7fdbff] drop-shadow-[0_0_8px_rgba(127,219,255,0.6)]">Bets</span>
              <div className="absolute -bottom-1 left-0 w-full h-[2px] bg-gradient-to-r from-[#f08bf0] to-[#7fdbff]"></div>
            </div>
            <div className="flex space-x-6 mb-4 md:mb-0">
              <Link
                href="#"
                className="text-gray-400 hover:text-[#7fdbff] transition-colors duration-300 relative group"
              >
                Terms
                <span className="absolute -bottom-1 left-0 w-0 h-[1px] bg-[#7fdbff] group-hover:w-full transition-all duration-300"></span>
              </Link>
              <Link
                href="#"
                className="text-gray-400 hover:text-[#7fdbff] transition-colors duration-300 relative group"
              >
                Privacy
                <span className="absolute -bottom-1 left-0 w-0 h-[1px] bg-[#7fdbff] group-hover:w-full transition-all duration-300"></span>
              </Link>
              <Link
                href="#"
                className="text-gray-400 hover:text-[#7fdbff] transition-colors duration-300 relative group"
              >
                Contact
                <span className="absolute -bottom-1 left-0 w-0 h-[1px] bg-[#7fdbff] group-hover:w-full transition-all duration-300"></span>
              </Link>
            </div>
            <div className="flex space-x-4">
              <Link
                href="#"
                className="text-gray-400 hover:text-[#7fdbff] transition-all duration-300 transform hover:scale-110"
              >
                <Twitter size={20} className="hover:drop-shadow-[0_0_8px_rgba(127,219,255,0.6)]" />
              </Link>
              <Link
                href="#"
                className="text-gray-400 hover:text-[#f08bf0] transition-all duration-300 transform hover:scale-110"
              >
                <Instagram size={20} className="hover:drop-shadow-[0_0_8px_rgba(240,139,240,0.6)]" />
              </Link>
            </div>
          </div>
          <div className="mt-8 text-center text-gray-500 text-sm">
            &copy; {new Date().getFullYear()} BooBets. All rights reserved. For adults 18+ only.
          </div>
        </div>
      </footer>
    </div>
  )
}

