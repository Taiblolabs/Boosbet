"use client"

import { useState } from "react"
import {
  Menu,
  X,
  Twitter,
  Instagram,
  User,
  Calendar,
  Trophy,
  Settings,
  LogOut,
  Bell,
  ChevronDown,
  Star,
  Award,
  Users,
} from "lucide-react"
import Link from "next/link"

export default function Dashboard() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [userDropdownOpen, setUserDropdownOpen] = useState(false)
  const [userData, setUserData] = useState({
    username: "Steve",
    joinDate: new Date().toISOString().split("T")[0],
    gamesPlayed: 12,
    wins: 5,
    level: -9999 ,
    points: -9999
    notifications: 2,
  })

  // Datos de actividad reciente (simulados)
  const recentActivity = [
    { id: 1, type: "game", game: "Memory Game", result: "Win", points: "+150", date: "2 hours ago" },
    {
      id: 2,
      type: "achievement",
      name: "Quick Thinker",
      description: "Complete a memory game in under 60 seconds",
      points: "+100",
      date: "Yesterday",
    },
    { id: 3, type: "game", game: "Memory Game", result: "Loss", points: "+25", date: "2 days ago" },
    { id: 4, type: "level", level: 3, points: "+200", date: "3 days ago" },
  ]

  // Estadísticas de juego (simuladas)
  const gameStats = [
    { name: "Memory Game", played: 8, wins: 5, bestScore: "00:45", lastPlayed: "Today" },
    { name: "BooBingo", played: 3, wins: 0, bestScore: "N/A", lastPlayed: "Yesterday" },
    { name: "Sensual Roulette", played: 1, wins: 0, bestScore: "N/A", lastPlayed: "3 days ago" },
  ]

  // Fecha base para la recopilación de datos
  const dataCollectionStartDate = "2024-03-01"

  return (
    <div className="min-h-screen bg-black text-white font-['Quicksand']">
      {/* Header */}
      <header className="bg-black sticky top-0 z-50 shadow-md border-b border-[#7fdbff] border-opacity-30">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="text-2xl md:text-3xl font-['Quicksand'] text-white font-bold relative">
            <Link href="/">
              <span className="text-[#f08bf0] drop-shadow-[0_0_8px_rgba(240,139,240,0.6)]">Boo</span>
              <span className="text-[#7fdbff] drop-shadow-[0_0_8px_rgba(127,219,255,0.6)]">Bets</span>
              <div className="absolute -bottom-1 left-0 w-full h-[2px] bg-gradient-to-r from-[#f08bf0] to-[#7fdbff]"></div>
            </Link>
          </div>

          {/* Mobile menu button */}
          <button className="md:hidden text-white" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X size={24} className="text-[#7fdbff]" /> : <Menu size={24} className="text-[#7fdbff]" />}
          </button>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/" className="text-white hover:text-[#7fdbff] transition-colors duration-300 relative group">
              Home
              <span className="absolute -bottom-1 left-0 w-0 h-[2px] bg-[#7fdbff] group-hover:w-full transition-all duration-300"></span>
            </Link>
            <Link
              href="/games"
              className="text-white hover:text-[#7fdbff] transition-colors duration-300 relative group"
            >
              Games
              <span className="absolute -bottom-1 left-0 w-0 h-[2px] bg-[#7fdbff] group-hover:w-full transition-all duration-300"></span>
            </Link>
            <Link href="#" className="text-white hover:text-[#7fdbff] transition-colors duration-300 relative group">
              Content
              <span className="absolute -bottom-1 left-0 w-0 h-[2px] bg-[#7fdbff] group-hover:w-full transition-all duration-300"></span>
            </Link>

            {/* Notifications */}
            <div className="relative">
              <button className="text-white hover:text-[#7fdbff] transition-colors duration-300">
                <Bell size={20} />
                {userData.notifications > 0 && (
                  <span className="absolute -top-1 -right-1 bg-[#f08bf0] text-white text-xs w-4 h-4 flex items-center justify-center rounded-full">
                    {userData.notifications}
                  </span>
                )}
              </button>
            </div>

            {/* User dropdown */}
            <div className="relative">
              <button
                className="flex items-center space-x-2 text-white hover:text-[#7fdbff] transition-colors duration-300"
                onClick={() => setUserDropdownOpen(!userDropdownOpen)}
              >
                <div className="w-8 h-8 bg-gradient-to-r from-[#f08bf0] to-[#7fdbff] rounded-full flex items-center justify-center">
                  <User size={16} className="text-black" />
                </div>
                <span>{userData.username}</span>
                <ChevronDown
                  size={16}
                  className={`transition-transform duration-300 ${userDropdownOpen ? "rotate-180" : ""}`}
                />
              </button>

              {userDropdownOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-black border border-[#7fdbff] border-opacity-30 rounded-md shadow-lg py-1 z-50">
                  <Link
                    href="/dashboard"
                    className="block px-4 py-2 text-sm text-white hover:bg-[#7fdbff]/10 transition-colors"
                  >
                    Dashboard
                  </Link>
                  <Link href="#" className="block px-4 py-2 text-sm text-white hover:bg-[#7fdbff]/10 transition-colors">
                    Profile
                  </Link>
                  <Link href="#" className="block px-4 py-2 text-sm text-white hover:bg-[#7fdbff]/10 transition-colors">
                    Settings
                  </Link>
                  <div className="border-t border-[#7fdbff] border-opacity-30 my-1"></div>
                  <Link
                    href="/"
                    className="block px-4 py-2 text-sm text-[#f08bf0] hover:bg-[#f08bf0]/10 transition-colors"
                  >
                    Sign Out
                  </Link>
                </div>
              )}
            </div>
          </nav>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden bg-black py-4 px-4 absolute w-full border-b border-[#7fdbff] border-opacity-30 z-50">
            <nav className="flex flex-col space-y-4">
              <Link href="/" className="text-white hover:text-[#7fdbff] transition-colors duration-300">
                Home
              </Link>
              <Link href="/games" className="text-white hover:text-[#7fdbff] transition-colors duration-300">
                Games
              </Link>
              <Link href="#" className="text-white hover:text-[#7fdbff] transition-colors duration-300">
                Content
              </Link>
              <div className="border-t border-[#7fdbff] border-opacity-30 pt-4">
                <div className="flex items-center space-x-2 mb-4">
                  <div className="w-8 h-8 bg-gradient-to-r from-[#f08bf0] to-[#7fdbff] rounded-full flex items-center justify-center">
                    <User size={16} className="text-black" />
                  </div>
                  <span>{userData.username}</span>
                </div>
                <Link
                  href="/dashboard"
                  className="flex items-center text-white hover:text-[#7fdbff] transition-colors duration-300 mb-2"
                >
                  <User size={16} className="mr-2" /> Dashboard
                </Link>
                <Link
                  href="#"
                  className="flex items-center text-white hover:text-[#7fdbff] transition-colors duration-300 mb-2"
                >
                  <Settings size={16} className="mr-2" /> Settings
                </Link>
                <Link
                  href="/"
                  className="flex items-center text-[#f08bf0] hover:text-[#f08bf0]/80 transition-colors duration-300"
                >
                  <LogOut size={16} className="mr-2" /> Sign Out
                </Link>
              </div>
            </nav>
          </div>
        )}
      </header>

      {/* Dashboard Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - User Profile */}
          <div className="lg:col-span-1">
            <div className="bg-black border border-[#7fdbff] border-opacity-30 rounded-lg p-6 mb-6">
              <div className="flex flex-col items-center mb-6">
                <div className="w-24 h-24 bg-gradient-to-r from-[#f08bf0] to-[#7fdbff] rounded-full flex items-center justify-center mb-4">
                  <User size={40} className="text-black" />
                </div>
                <h2 className="text-xl font-bold">{userData.username}</h2>
                <div className="flex items-center text-sm text-gray-400 mt-1">
                  <Calendar size={14} className="mr-1" />
                  <span>Joined {userData.joinDate}</span>
                </div>
                <div className="mt-4 w-full bg-gray-800 rounded-full h-2.5">
                  <div
                    className="bg-gradient-to-r from-[#f08bf0] to-[#7fdbff] h-2.5 rounded-full"
                    style={{ width: "65%" }}
                  ></div>
                </div>
                <div className="flex justify-between w-full text-xs text-gray-400 mt-1">
                  <span>Level {userData.level}</span>
                  <span>{userData.points} / 2000 XP</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="bg-black border border-[#7fdbff] border-opacity-20 rounded-lg p-3 text-center">
                  <div className="text-xl font-bold text-[#7fdbff]">{userData.gamesPlayed}</div>
                  <div className="text-xs text-gray-400">Games Played</div>
                </div>
                <div className="bg-black border border-[#f08bf0] border-opacity-20 rounded-lg p-3 text-center">
                  <div className="text-xl font-bold text-[#f08bf0]">{userData.wins}</div>
                  <div className="text-xs text-gray-400">Wins</div>
                </div>
              </div>

              <div className="space-y-2">
                <h3 className="text-sm font-medium text-gray-300 mb-2">Data Collection</h3>
                <div className="flex justify-between items-center text-sm">
                  <span className="text-gray-400">Collection started:</span>
                  <span className="text-white">{dataCollectionStartDate}</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span className="text-gray-400">Data retention:</span>
                  <span className="text-white">90 days</span>
                </div>
                <div className="mt-4">
                  <button className="text-[#7fdbff] text-sm hover:underline">Manage data settings</button>
                </div>
              </div>
            </div>

            {/* Game Stats */}
            <div className="bg-black border border-[#7fdbff] border-opacity-30 rounded-lg p-6">
              <h3 className="text-lg font-bold mb-4 flex items-center">
                <Trophy size={18} className="text-[#f08bf0] mr-2" />
                Game Statistics
              </h3>
              <div className="space-y-4">
                {gameStats.map((game, index) => (
                  <div key={index} className="border-b border-gray-800 pb-3 last:border-0 last:pb-0">
                    <div className="flex justify-between items-center mb-1">
                      <span className="font-medium">{game.name}</span>
                      <span className="text-xs text-gray-400">Last played: {game.lastPlayed}</span>
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-xs text-gray-400">
                      <div>
                        <span className="block">Played</span>
                        <span className="text-white">{game.played}</span>
                      </div>
                      <div>
                        <span className="block">Wins</span>
                        <span className="text-white">{game.wins}</span>
                      </div>
                      <div>
                        <span className="block">Best Score</span>
                        <span className="text-white">{game.bestScore}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column - Activity & Games */}
          <div className="lg:col-span-2">
            {/* Welcome Banner */}
            <div className="bg-gradient-to-r from-[#f08bf0]/20 to-[#7fdbff]/20 border border-[#7fdbff] border-opacity-30 rounded-lg p-6 mb-6">
              <h1 className="text-2xl font-bold mb-2">
                Welcome back, <span className="text-[#f08bf0]">{userData.username}</span>!
              </h1>
              <p className="text-gray-300 mb-4">Continue your gaming journey or try something new today.</p>
              <div className="flex flex-wrap gap-3">
                <Link href="/games">
                  <button className="bg-[#f08bf0] hover:bg-[#f08bf0]/80 text-white px-4 py-2 rounded-full transition-all duration-300 hover:scale-105 shadow-[0_0_15px_rgba(240,139,240,0.4)]">
                    Play Games
                  </button>
                </Link>
                <Link href="/memory-game">
                  <button className="bg-[#7fdbff] hover:bg-[#7fdbff]/80 text-black px-4 py-2 rounded-full transition-all duration-300 hover:scale-105 shadow-[0_0_15px_rgba(127,219,255,0.4)]">
                    Memory Game
                  </button>
                </Link>
              </div>
            </div>

            {/* Recent Activity */}
            <div className="bg-black border border-[#7fdbff] border-opacity-30 rounded-lg p-6 mb-6">
              <h3 className="text-lg font-bold mb-4">Recent Activity</h3>
              <div className="space-y-4">
                {recentActivity.map((activity) => (
                  <div
                    key={activity.id}
                    className="flex items-start border-b border-gray-800 pb-3 last:border-0 last:pb-0"
                  >
                    <div
                      className={`w-10 h-10 rounded-full flex items-center justify-center mr-3 ${
                        activity.type === "game"
                          ? "bg-[#7fdbff]/20 text-[#7fdbff]"
                          : activity.type === "achievement"
                            ? "bg-[#f08bf0]/20 text-[#f08bf0]"
                            : "bg-purple-500/20 text-purple-500"
                      }`}
                    >
                      {activity.type === "game" && <Trophy size={18} />}
                      {activity.type === "achievement" && <Star size={18} />}
                      {activity.type === "level" && <Award size={18} />}
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between items-start">
                        <div>
                          {activity.type === "game" && (
                            <p className="font-medium">
                              Played {activity.game} -{" "}
                              <span className={activity.result === "Win" ? "text-[#7fdbff]" : "text-gray-400"}>
                                {activity.result}
                              </span>
                            </p>
                          )}
                          {activity.type === "achievement" && (
                            <p className="font-medium">
                              Achievement Unlocked: <span className="text-[#f08bf0]">{activity.name}</span>
                            </p>
                          )}
                          {activity.type === "level" && (
                            <p className="font-medium">
                              Reached Level <span className="text-purple-500">{activity.level}</span>
                            </p>
                          )}
                          {activity.type === "achievement" && (
                            <p className="text-xs text-gray-400 mt-1">{activity.description}</p>
                          )}
                        </div>
                        <span className="text-xs text-gray-400">{activity.date}</span>
                      </div>
                      <div className="text-sm text-[#f08bf0] mt-1">{activity.points} points</div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-4 text-center">
                <button className="text-[#7fdbff] text-sm hover:underline">View all activity</button>
              </div>
            </div>

            {/* Multiplayer Friends */}
            <div className="bg-black border border-[#7fdbff] border-opacity-30 rounded-lg p-6">
              <h3 className="text-lg font-bold mb-4">Multiplayer</h3>
              <div className="text-center py-8">
                <div className="w-16 h-16 bg-[#7fdbff]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users size={24} className="text-[#7fdbff]" />
                </div>
                <h4 className="text-lg font-medium mb-2">Invite Friends to Play</h4>
                <p className="text-gray-400 text-sm mb-4">
                  Challenge your friends to multiplayer games and compete for the highest scores!
                </p>
                <button className="bg-[#7fdbff] hover:bg-[#7fdbff]/80 text-black px-4 py-2 rounded-full transition-all duration-300 hover:scale-105 shadow-[0_0_15px_rgba(127,219,255,0.4)]">
                  Find Friends
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-black py-8 border-t border-[#7fdbff] border-opacity-30">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="text-xl font-['Quicksand'] font-bold mb-4 md:mb-0 relative">
              <span className="text-[#f08bf0] drop-shadow-[0_0_8px_rgba(240,139,240,0.6)]">Boo</span>
              <span className="text-[#7fdbff] drop-shadow-[0_0_8px_rgba(127,219,255,0.6)]">Bets</span>
              <div className="absolute -bottom-1 left-0 w-full h-[2px] bg-gradient-to-r from-[#f08bf0] to-[#7fdbff]"></div>
            </div>
            <div className="flex space-x-6 mb-4 md:mb-0">
              <Link
                href="#"
                className="text-gray-400 hover:text-[#7fdbff] transition-colors duration-300 relative group"
              >
                Terms
                <span className="absolute -bottom-1 left-0 w-0 h-[1px] bg-[#7fdbff] group-hover:w-full transition-all duration-300"></span>
              </Link>
              <Link
                href="#"
                className="text-gray-400 hover:text-[#7fdbff] transition-colors duration-300 relative group"
              >
                Privacy
                <span className="absolute -bottom-1 left-0 w-0 h-[1px] bg-[#7fdbff] group-hover:w-full transition-all duration-300"></span>
              </Link>
              <Link
                href="#"
                className="text-gray-400 hover:text-[#7fdbff] transition-colors duration-300 relative group"
              >
                Contact
                <span className="absolute -bottom-1 left-0 w-0 h-[1px] bg-[#7fdbff] group-hover:w-full transition-all duration-300"></span>
              </Link>
            </div>
            <div className="flex space-x-4">
              <Link
                href="#"
                className="text-gray-400 hover:text-[#7fdbff] transition-all duration-300 transform hover:scale-110"
              >
                <Twitter size={20} className="hover:drop-shadow-[0_0_8px_rgba(127,219,255,0.6)]" />
              </Link>
              <Link
                href="#"
                className="text-gray-400 hover:text-[#f08bf0] transition-all duration-300 transform hover:scale-110"
              >
                <Instagram size={20} className="hover:drop-shadow-[0_0_8px_rgba(240,139,240,0.6)]" />
              </Link>
            </div>
          </div>
          <div className="mt-8 text-center text-gray-500 text-sm">
            &copy; {new Date().getFullYear()} BooBets. All rights reserved. For adults 18+ only.
          </div>
        </div>
      </footer>
    </div>
  )
}

