// Board theme type
export interface BoardTheme {
  id: string
  name: string
  description: string
  cardBack: string
  background: string
  borderColor: string
  isCustom?: boolean
  isPublic?: boolean
  createdBy?: string
  cardStyle?: string
}

// Custom board type
export interface CustomBoard extends BoardTheme {
  isCustom: true
  images: string[]
  createdBy: string
  isPublic: boolean
}

// Card type
export interface Card {
  id: number
  emoji: string
  image?: string
  isFlipped: boolean
  isMatched: boolean
}

// Game difficulty
export interface GameDifficulty {
  id: string
  name: string
  pairs: number
  gridSize: string
}

