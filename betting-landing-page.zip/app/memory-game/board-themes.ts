import type { BoardTheme, GameDifficulty } from "./types"

// Predefined board themes
export const boardThemes: BoardTheme[] = [
  {
    id: "classic",
    name: "Classic Emojis",
    description: "The classic memory game with fun emoji cards",
    cardBack: "bg-gradient-to-br from-[#7fdbff] to-[#f08bf0]",
    background: "bg-black",
    borderColor: "border-[#7fdbff]",
    cardStyle: "text-4xl",
  },
  {
    id: "neon",
    name: "Neon Arcade",
    description: "Vibrant neon-themed gaming cards",
    cardBack: "bg-gradient-to-br from-[#00ff00] to-[#ff00ff]",
    background: "bg-[#0a0a20]",
    borderColor: "border-[#00ff00]",
    cardStyle: "text-4xl",
  },
  {
    id: "space",
    name: "Cosmic Journey",
    description: "Space-themed cards with celestial symbols",
    cardBack: "bg-gradient-to-br from-[#000033] to-[#6600cc]",
    background: "bg-[#000011]",
    borderColor: "border-[#6600cc]",
    cardStyle: "text-4xl",
  },
]

// Game difficulty levels - all with 4 columns but different number of rows
export const difficultyLevels: GameDifficulty[] = [
  {
    id: "easy",
    name: "Easy",
    pairs: 6,
    gridSize: "grid-cols-4 grid-rows-3",
  },
  {
    id: "medium",
    name: "Medium",
    pairs: 8,
    gridSize: "grid-cols-4 grid-rows-4",
  },
  {
    id: "hard",
    name: "Hard",
    pairs: 12,
    gridSize: "grid-cols-4 grid-rows-6",
  },
]

// Emoji sets for different themes
export const emojiSets = {
  classic: ["🎮", "🎲", "💰", "💎", "🏆", "🃏", "🎯", "🎪", "🎭", "🎨", "🎬", "🎵"],
  neon: ["👾", "🕹️", "🎮", "🎯", "🏆", "🎲", "🎪", "🎭", "🎨", "🎬", "🎵", "🎸"],
  space: ["🚀", "🛸", "🌌", "🌠", "🪐", "🌕", "🌍", "☄️", "👽", "🌟", "🔭", "🌃"],
}

