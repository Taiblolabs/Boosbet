"use client"

import { useState, useEffect } from "react"
import { Menu, X, ArrowLeft, Trophy, Timer, RefreshCw, Twitter, Instagram, Share2 } from "lucide-react"
import Link from "next/link"
import BoardSelection from "./components/board-selection"
import CreateBoard from "./components/create-board"
import type { BoardTheme, Card, CustomBoard, GameDifficulty } from "./types"
import { boardThemes, difficultyLevels, emojiSets } from "./board-themes"

export default function MemoryGame() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [cards, setCards] = useState<Card[]>([])
  const [flippedCards, setFlippedCards] = useState<number[]>([])
  const [matchedPairs, setMatchedPairs] = useState(0)
  const [moves, setMoves] = useState(0)
  const [gameStarted, setGameStarted] = useState(false)
  const [gameCompleted, setGameCompleted] = useState(false)
  const [timer, setTimer] = useState(0)
  const [timerInterval, setTimerInterval] = useState<NodeJS.Timeout | null>(null)

  // New state for board selection
  const [gameState, setGameState] = useState<"selection" | "creation" | "playing">("selection")
  const [selectedBoard, setSelectedBoard] = useState<BoardTheme>(boardThemes[0])
  const [selectedDifficulty, setSelectedDifficulty] = useState<GameDifficulty>(difficultyLevels[0])
  const [customBoards, setCustomBoards] = useState<CustomBoard[]>([])
  const [totalPairs, setTotalPairs] = useState(8)

  // Handle board selection
  const handleBoardSelection = (board: BoardTheme, difficulty: GameDifficulty) => {
    setSelectedBoard(board)
    setSelectedDifficulty(difficulty)
    setTotalPairs(difficulty.pairs)
    setGameState("playing")
    initializeGame(board, difficulty.pairs)
  }

  // Handle custom board creation
  const handleCreateBoard = () => {
    setGameState("creation")
  }

  // Handle saving a custom board
  const handleSaveCustomBoard = (board: CustomBoard) => {
    setCustomBoards((prev) => [...prev, board])
    setGameState("selection")
  }

  // Initialize game with selected board
  const initializeGame = (board: BoardTheme, pairs = 8) => {
    // Create pairs of cards
    const initialCards: Card[] = []

    // If it's a custom board with images
    if (board.isCustom && (board as CustomBoard).images) {
      const customBoard = board as CustomBoard
      const imagesToUse = customBoard.images.slice(0, pairs)

      imagesToUse.forEach((image, index) => {
        // Create two cards with the same image (a pair)
        initialCards.push({
          id: index * 2,
          emoji: "",
          image: image,
          isFlipped: false,
          isMatched: false,
        })
        initialCards.push({
          id: index * 2 + 1,
          emoji: "",
          image: image,
          isFlipped: false,
          isMatched: false,
        })
      })
    } else {
      // Use emojis based on the theme
      const themeEmojis = emojiSets[board.id as keyof typeof emojiSets] || emojiSets.classic
      const emojisToUse = themeEmojis.slice(0, pairs)

      emojisToUse.forEach((emoji, index) => {
        // Create two cards with the same emoji (a pair)
        initialCards.push({
          id: index * 2,
          emoji,
          isFlipped: false,
          isMatched: false,
        })
        initialCards.push({
          id: index * 2 + 1,
          emoji,
          isFlipped: false,
          isMatched: false,
        })
      })
    }

    // Shuffle the cards
    const shuffledCards = [...initialCards].sort(() => Math.random() - 0.5)
    setCards(shuffledCards)
    setFlippedCards([])
    setMatchedPairs(0)
    setMoves(0)
    setGameCompleted(false)
    setTimer(0)

    // Clear any existing timer
    if (timerInterval) {
      clearInterval(timerInterval)
      setTimerInterval(null)
    }

    setGameStarted(false)
  }

  // Start the game timer
  const startTimer = () => {
    if (timerInterval) return

    const interval = setInterval(() => {
      setTimer((prevTimer) => prevTimer + 1)
    }, 1000)

    setTimerInterval(interval)
  }

  // Handle card click
  const handleCardClick = (cardId: number) => {
    // Start the game and timer on first card click
    if (!gameStarted) {
      setGameStarted(true)
      startTimer()
    }

    // Ignore clicks if game is completed or if two cards are already flipped
    if (gameCompleted || flippedCards.length >= 2) return

    // Find the clicked card
    const clickedCard = cards.find((card) => card.id === cardId)

    // Ignore if card is already flipped or matched
    if (!clickedCard || clickedCard.isFlipped || clickedCard.isMatched) return

    // Flip the card
    const updatedCards = cards.map((card) => (card.id === cardId ? { ...card, isFlipped: true } : card))
    setCards(updatedCards)

    // Add card to flipped cards
    const updatedFlippedCards = [...flippedCards, cardId]
    setFlippedCards(updatedFlippedCards)

    // If two cards are flipped, check for a match
    if (updatedFlippedCards.length === 2) {
      setMoves((prevMoves) => prevMoves + 1)

      const [firstCardId, secondCardId] = updatedFlippedCards
      const firstCard = updatedCards.find((card) => card.id === firstCardId)
      const secondCard = updatedCards.find((card) => card.id === secondCardId)

      // Check if the cards match (either by emoji or image)
      const isMatch =
        firstCard &&
        secondCard &&
        ((firstCard.emoji && firstCard.emoji === secondCard.emoji) ||
          (firstCard.image && firstCard.image === secondCard.image))

      if (isMatch) {
        // Match found
        setTimeout(() => {
          const matchedCards = updatedCards.map((card) =>
            card.id === firstCardId || card.id === secondCardId ? { ...card, isMatched: true } : card,
          )
          setCards(matchedCards)
          setFlippedCards([])
          setMatchedPairs((prevMatchedPairs) => {
            const newMatchedPairs = prevMatchedPairs + 1
            // Check if all pairs are matched
            if (newMatchedPairs === totalPairs) {
              setGameCompleted(true)
              if (timerInterval) {
                clearInterval(timerInterval)
                setTimerInterval(null)
              }
            }
            return newMatchedPairs
          })
        }, 500)
      } else {
        // No match, flip cards back
        setTimeout(() => {
          const resetCards = updatedCards.map((card) =>
            card.id === firstCardId || card.id === secondCardId ? { ...card, isFlipped: false } : card,
          )
          setCards(resetCards)
          setFlippedCards([])
        }, 1000)
      }
    }
  }

  // Format time for display (mm:ss)
  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60)
    const remainingSeconds = seconds % 60
    return `${minutes.toString().padStart(2, "0")}:${remainingSeconds.toString().padStart(2, "0")}`
  }

  // Share board
  const handleShareBoard = () => {
    if (selectedBoard.isCustom) {
      alert("Board sharing link generated! (This would actually share the board in a real implementation)")
    }
  }

  // Return to board selection
  const handleBackToSelection = () => {
    if (timerInterval) {
      clearInterval(timerInterval)
      setTimerInterval(null)
    }
    setGameState("selection")
  }

  // Clean up timer on unmount
  useEffect(() => {
    return () => {
      if (timerInterval) {
        clearInterval(timerInterval)
      }
    }
  }, [])

  return (
    <div className={`min-h-screen ${selectedBoard.background || "bg-black"} text-white font-['Quicksand']`}>
      {/* Header */}
      <header className="bg-black sticky top-0 z-50 shadow-md border-b border-[#7fdbff] border-opacity-30">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="text-2xl md:text-3xl font-['Quicksand'] text-white font-bold relative">
            <Link href="/">
              <span className="text-[#f08bf0] drop-shadow-[0_0_8px_rgba(240,139,240,0.6)]">Boo</span>
              <span className="text-[#7fdbff] drop-shadow-[0_0_8px_rgba(127,219,255,0.6)]">Bets</span>
              <div className="absolute -bottom-1 left-0 w-full h-[2px] bg-gradient-to-r from-[#f08bf0] to-[#7fdbff]"></div>
            </Link>
          </div>

          {/* Mobile menu button */}
          <button className="md:hidden text-white" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X size={24} className="text-[#7fdbff]" /> : <Menu size={24} className="text-[#7fdbff]" />}
          </button>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/" className="text-white hover:text-[#7fdbff] transition-colors duration-300 relative group">
              Home
              <span className="absolute -bottom-1 left-0 w-0 h-[2px] bg-[#7fdbff] group-hover:w-full transition-all duration-300"></span>
            </Link>
            <Link
              href="/games"
              className="text-white hover:text-[#7fdbff] transition-colors duration-300 relative group"
            >
              Games
              <span className="absolute -bottom-1 left-0 w-0 h-[2px] bg-[#7fdbff] group-hover:w-full transition-all duration-300"></span>
            </Link>
            <Link href="#" className="text-white hover:text-[#7fdbff] transition-colors duration-300 relative group">
              Content
              <span className="absolute -bottom-1 left-0 w-0 h-[2px] bg-[#7fdbff] group-hover:w-full transition-all duration-300"></span>
            </Link>
            <Link href="#" className="text-white hover:text-[#7fdbff] transition-colors duration-300 relative group">
              Register
              <span className="absolute -bottom-1 left-0 w-0 h-[2px] bg-[#7fdbff] group-hover:w-full transition-all duration-300"></span>
            </Link>
            <Link href="#" className="text-white hover:text-[#7fdbff] transition-colors duration-300 relative group">
              Login
              <span className="absolute -bottom-1 left-0 w-0 h-[2px] bg-[#7fdbff] group-hover:w-full transition-all duration-300"></span>
            </Link>
            <Link href="/auth">
              <button className="bg-[#f08bf0] hover:bg-[#f08bf0]/80 text-white px-4 py-2 rounded-full transition-all duration-300 hover:scale-105 shadow-[0_0_15px_rgba(240,139,240,0.4)] hover:shadow-[0_0_20px_rgba(240,139,240,0.5)]">
                Join Now
              </button>
            </Link>
          </nav>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden bg-black py-4 px-4 absolute w-full border-b border-[#7fdbff] border-opacity-30">
            <nav className="flex flex-col space-y-4">
              <Link href="/" className="text-white hover:text-[#7fdbff] transition-colors duration-300">
                Home
              </Link>
              <Link href="/games" className="text-white hover:text-[#7fdbff] transition-colors duration-300">
                Games
              </Link>
              <Link href="#" className="text-white hover:text-[#7fdbff] transition-colors duration-300">
                Content
              </Link>
              <Link href="#" className="text-white hover:text-[#7fdbff] transition-colors duration-300">
                Register
              </Link>
              <Link href="#" className="text-white hover:text-[#7fdbff] transition-colors duration-300">
                Login
              </Link>
              <Link href="/auth" className="w-full">
                <button className="bg-[#f08bf0] hover:bg-[#f08bf0]/80 text-white px-4 py-2 rounded-full transition-transform duration-300 hover:scale-105 w-full shadow-[0_0_15px_rgba(240,139,240,0.4)]">
                  Join Now
                </button>
              </Link>
            </nav>
          </div>
        )}
      </header>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        {/* Board Selection Screen */}
        {gameState === "selection" && (
          <BoardSelection
            onSelectBoard={handleBoardSelection}
            onCreateCustomBoard={handleCreateBoard}
            customBoards={customBoards}
          />
        )}

        {/* Create Custom Board Screen */}
        {gameState === "creation" && (
          <CreateBoard onSave={handleSaveCustomBoard} onCancel={() => setGameState("selection")} />
        )}

        {/* Game Screen */}
        {gameState === "playing" && (
          <div className="relative z-10">
            {/* Back to Selection button */}
            <div className="mb-6 flex justify-between items-center">
              <button
                onClick={handleBackToSelection}
                className="inline-flex items-center text-[#7fdbff] hover:text-white transition-colors duration-300"
              >
                <ArrowLeft size={20} className="mr-2" />
                Back to Board Selection
              </button>

              {selectedBoard.isCustom && (
                <button
                  onClick={handleShareBoard}
                  className="inline-flex items-center text-[#f08bf0] hover:text-white transition-colors duration-300"
                >
                  <Share2 size={20} className="mr-2" />
                  Share Board
                </button>
              )}
            </div>

            {/* Game Title */}
            <div className="text-center mb-8">
              <h1 className="text-3xl md:text-4xl font-bold mb-2">
                <span className="text-[#f08bf0] drop-shadow-[0_0_8px_rgba(240,139,240,0.6)]">Memory</span>{" "}
                <span className="text-[#7fdbff] drop-shadow-[0_0_8px_rgba(127,219,255,0.6)]">Game</span>
              </h1>
              <p className="text-gray-300">
                Playing with <span className="text-[#f08bf0]">{selectedBoard.name}</span> board - Match pairs of cards
                to win. Click on a card to flip it.
              </p>
            </div>

            {/* Game Stats */}
            <div className="flex flex-wrap justify-center gap-2 sm:gap-4 md:gap-6 mb-6">
              <div className="flex items-center bg-black border border-[#7fdbff] border-opacity-30 rounded-full px-3 py-1 sm:px-4 sm:py-2 text-xs sm:text-sm">
                <Trophy className="text-[#f08bf0] mr-1 sm:mr-2" size={16} />
                <span>
                  Pairs: {matchedPairs}/{totalPairs}
                </span>
              </div>
              <div className="flex items-center bg-black border border-[#7fdbff] border-opacity-30 rounded-full px-3 py-1 sm:px-4 sm:py-2 text-xs sm:text-sm">
                <Timer className="text-[#7fdbff] mr-1 sm:mr-2" size={16} />
                <span>Time: {formatTime(timer)}</span>
              </div>
              <div className="flex items-center bg-black border border-[#7fdbff] border-opacity-30 rounded-full px-3 py-1 sm:px-4 sm:py-2 text-xs sm:text-sm">
                <span>Moves: {moves}</span>
              </div>
            </div>

            {/* Game Board */}
            <div className="max-w-md mx-auto mb-8">
              <div className={`grid ${selectedDifficulty.gridSize} gap-1.5`}>
                {cards.map((card) => (
                  <div
                    key={card.id}
                    onClick={() => handleCardClick(card.id)}
                    className={`aspect-square flex items-center justify-center rounded-md cursor-pointer transition-all duration-300 transform ${
                      card.isFlipped || card.isMatched
                        ? "bg-black border border-[#f08bf0] shadow-[0_0_10px_rgba(240,139,240,0.4)]"
                        : selectedBoard.cardBack
                    } ${card.isMatched ? "opacity-70" : "opacity-100"}`}
                  >
                    {card.isFlipped || card.isMatched ? (
                      card.image ? (
                        <img
                          src={card.image || "/placeholder.svg"}
                          alt="Card"
                          className={selectedBoard.cardStyle || "w-full h-full object-cover rounded-md"}
                        />
                      ) : (
                        <span className={selectedBoard.cardStyle || "text-xl sm:text-2xl"}>{card.emoji}</span>
                      )
                    ) : (
                      <span className="text-sm sm:text-base text-black font-bold">?</span>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Game Controls */}
            <div className="flex justify-center mb-8">
              <button
                onClick={() => initializeGame(selectedBoard, selectedDifficulty.pairs)}
                className="flex items-center bg-[#f08bf0] hover:bg-[#f08bf0]/80 text-white px-6 py-3 rounded-full font-bold transition-all duration-300 hover:scale-105 shadow-[0_0_15px_rgba(240,139,240,0.4)]"
              >
                <RefreshCw size={18} className="mr-2" />
                Restart Game
              </button>
            </div>

            {/* Game Completion Message */}
            {gameCompleted && (
              <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50">
                <div className="bg-black border-2 border-[#7fdbff] rounded-lg p-8 max-w-md text-center shadow-[0_0_30px_rgba(127,219,255,0.5)]">
                  <div className="text-6xl mb-4">🎉</div>
                  <h2 className="text-2xl font-bold mb-2 text-[#7fdbff]">Congratulations!</h2>
                  <p className="text-gray-300 mb-4">You completed the memory game!</p>
                  <div className="flex justify-center gap-4 mb-6">
                    <div className="text-center">
                      <div className="text-xl font-bold text-[#f08bf0]">{moves}</div>
                      <div className="text-sm text-gray-400">Moves</div>
                    </div>
                    <div className="text-center">
                      <div className="text-xl font-bold text-[#f08bf0]">{formatTime(timer)}</div>
                      <div className="text-sm text-gray-400">Time</div>
                    </div>
                  </div>
                  <div className="flex flex-col sm:flex-row justify-center gap-4">
                    <button
                      onClick={() => initializeGame(selectedBoard, selectedDifficulty.pairs)}
                      className="bg-[#f08bf0] hover:bg-[#f08bf0]/80 text-white px-6 py-3 rounded-full font-bold transition-all duration-300 hover:scale-105 shadow-[0_0_15px_rgba(240,139,240,0.4)]"
                    >
                      Play Again
                    </button>
                    <button
                      onClick={handleBackToSelection}
                      className="bg-[#7fdbff] hover:bg-[#7fdbff]/80 text-black px-6 py-3 rounded-full font-bold transition-all duration-300 hover:scale-105 shadow-[0_0_15px_rgba(127,219,255,0.4)]"
                    >
                      Try Another Board
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Footer */}
      <footer className="bg-black py-8 border-t border-[#7fdbff] border-opacity-30">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="text-xl font-['Quicksand'] font-bold mb-4 md:mb-0 relative">
              <span className="text-[#f08bf0] drop-shadow-[0_0_8px_rgba(240,139,240,0.6)]">Boo</span>
              <span className="text-[#7fdbff] drop-shadow-[0_0_8px_rgba(127,219,255,0.6)]">Bets</span>
              <div className="absolute -bottom-1 left-0 w-full h-[2px] bg-gradient-to-r from-[#f08bf0] to-[#7fdbff]"></div>
            </div>
            <div className="flex space-x-6 mb-4 md:mb-0">
              <Link
                href="#"
                className="text-gray-400 hover:text-[#7fdbff] transition-colors duration-300 relative group"
              >
                Terms
                <span className="absolute -bottom-1 left-0 w-0 h-[1px] bg-[#7fdbff] group-hover:w-full transition-all duration-300"></span>
              </Link>
              <Link
                href="#"
                className="text-gray-400 hover:text-[#7fdbff] transition-colors duration-300 relative group"
              >
                Privacy
                <span className="absolute -bottom-1 left-0 w-0 h-[1px] bg-[#7fdbff] group-hover:w-full transition-all duration-300"></span>
              </Link>
              <Link
                href="#"
                className="text-gray-400 hover:text-[#7fdbff] transition-colors duration-300 relative group"
              >
                Contact
                <span className="absolute -bottom-1 left-0 w-0 h-[1px] bg-[#7fdbff] group-hover:w-full transition-all duration-300"></span>
              </Link>
            </div>
            <div className="flex space-x-4">
              <Link
                href="#"
                className="text-gray-400 hover:text-[#7fdbff] transition-all duration-300 transform hover:scale-110"
              >
                <Twitter size={20} className="hover:drop-shadow-[0_0_8px_rgba(127,219,255,0.6)]" />
              </Link>
              <Link
                href="#"
                className="text-gray-400 hover:text-[#f08bf0] transition-all duration-300 transform hover:scale-110"
              >
                <Instagram size={20} className="hover:drop-shadow-[0_0_8px_rgba(240,139,240,0.6)]" />
              </Link>
            </div>
          </div>
          <div className="mt-8 text-center text-gray-500 text-sm">
            &copy; {new Date().getFullYear()} BooBets. All rights reserved. For adults 18+ only.
          </div>
        </div>
      </footer>
    </div>
  )
}

