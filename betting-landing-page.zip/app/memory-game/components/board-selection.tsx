"use client"

import { useState } from "react"
import type { BoardTheme, GameDifficulty } from "../types"
import { boardThemes, difficultyLevels } from "../board-themes"
import { Plus, Globe, Lock, Check } from "lucide-react"

interface BoardSelectionProps {
  onSelectBoard: (board: BoardTheme, difficulty: GameDifficulty) => void
  onCreateCustomBoard: () => void
  customBoards: BoardTheme[]
}

export default function BoardSelection({ onSelectBoard, onCreateCustomBoard, customBoards = [] }: BoardSelectionProps) {
  const [selectedBoard, setSelectedBoard] = useState<BoardTheme>(boardThemes[0])
  const [selectedDifficulty, setSelectedDifficulty] = useState<GameDifficulty>(difficultyLevels[0])
  const [activeTab, setActiveTab] = useState<"predefined" | "custom">("predefined")

  const allBoards = activeTab === "predefined" ? boardThemes : customBoards

  return (
    <div className="w-full max-w-4xl mx-auto bg-black border border-[#7fdbff] border-opacity-30 rounded-lg p-6">
      <h2 className="text-2xl font-bold mb-6 text-center">
        <span className="text-[#f08bf0] drop-shadow-[0_0_8px_rgba(240,139,240,0.6)]">Select</span>{" "}
        <span className="text-[#7fdbff] drop-shadow-[0_0_8px_rgba(127,219,255,0.6)]">Board</span>
      </h2>

      {/* Tabs */}
      <div className="flex mb-6 border-b border-[#7fdbff] border-opacity-30">
        <button
          className={`px-4 py-2 ${activeTab === "predefined" ? "text-[#7fdbff] border-b-2 border-[#7fdbff]" : "text-gray-400"}`}
          onClick={() => setActiveTab("predefined")}
        >
          Predefined Boards
        </button>
        <button
          className={`px-4 py-2 ${activeTab === "custom" ? "text-[#7fdbff] border-b-2 border-[#7fdbff]" : "text-gray-400"}`}
          onClick={() => setActiveTab("custom")}
        >
          Custom Boards
        </button>
      </div>

      {/* Board Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 mb-6">
        {allBoards.map((board) => (
          <div
            key={board.id}
            className={`border rounded-lg p-3 sm:p-4 cursor-pointer transition-all duration-300 hover:scale-105 ${
              selectedBoard.id === board.id
                ? "border-[#f08bf0] shadow-[0_0_15px_rgba(240,139,240,0.4)]"
                : "border-gray-700 hover:border-[#7fdbff]"
            }`}
            onClick={() => setSelectedBoard(board)}
          >
            <div className={`aspect-video rounded-md mb-2 sm:mb-3 flex items-center justify-center ${board.cardBack}`}>
              <span className="text-2xl">?</span>
            </div>
            <h3 className="font-bold mb-1 text-sm sm:text-base">{board.name}</h3>
            <p className="text-xs sm:text-sm text-gray-400 mb-2">{board.description}</p>

            {board.isCustom && (
              <div className="flex items-center text-xs text-gray-500 mt-2">
                {board.isPublic ? (
                  <Globe size={12} className="mr-1 text-[#7fdbff]" />
                ) : (
                  <Lock size={12} className="mr-1 text-[#f08bf0]" />
                )}
                <span>{board.isPublic ? "Public" : "Private"}</span>
              </div>
            )}

            {selectedBoard.id === board.id && (
              <div className="absolute top-2 right-2 bg-[#f08bf0] rounded-full p-1">
                <Check size={16} className="text-white" />
              </div>
            )}
          </div>
        ))}

        {/* Create Custom Board Button (only in custom tab) */}
        {activeTab === "custom" && (
          <div
            className="border border-dashed border-gray-700 rounded-lg p-4 cursor-pointer flex flex-col items-center justify-center hover:border-[#7fdbff] transition-all duration-300 hover:scale-105"
            onClick={onCreateCustomBoard}
          >
            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-black border border-[#7fdbff] flex items-center justify-center mb-2">
              <Plus size={20} className="text-[#7fdbff]" />
            </div>
            <p className="text-center text-xs sm:text-sm text-gray-400">Create Custom Board</p>
          </div>
        )}
      </div>

      {/* Difficulty Selection */}
      <div className="mb-6">
        <h3 className="text-lg font-bold mb-3">Difficulty</h3>
        <div className="flex space-x-4">
          {difficultyLevels.map((difficulty) => (
            <button
              key={difficulty.id}
              className={`px-4 py-2 rounded-full ${
                selectedDifficulty.id === difficulty.id
                  ? "bg-[#f08bf0] text-white shadow-[0_0_15px_rgba(240,139,240,0.4)]"
                  : "bg-transparent border border-gray-700 text-gray-300 hover:border-[#7fdbff]"
              }`}
              onClick={() => setSelectedDifficulty(difficulty)}
            >
              {difficulty.name}
            </button>
          ))}
        </div>
      </div>

      {/* Start Game Button */}
      <div className="text-center">
        <button
          className="bg-[#f08bf0] hover:bg-[#f08bf0]/80 text-white px-6 py-3 rounded-full font-bold transition-all duration-300 hover:scale-105 shadow-[0_0_15px_rgba(240,139,240,0.4)]"
          onClick={() => onSelectBoard(selectedBoard, selectedDifficulty)}
        >
          Start Game
        </button>
      </div>
    </div>
  )
}

