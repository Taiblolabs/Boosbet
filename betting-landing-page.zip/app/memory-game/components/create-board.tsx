"use client"

import type React from "react"

import { useState } from "react"
import { Upload, X, Globe, Lock, ArrowLeft } from "lucide-react"
import type { CustomBoard } from "../types"

interface CreateBoardProps {
  onSave: (board: CustomBoard) => void
  onCancel: () => void
}

export default function CreateBoard({ onSave, onCancel }: CreateBoardProps) {
  const [boardName, setBoardName] = useState("")
  const [description, setDescription] = useState("")
  const [isPublic, setIsPublic] = useState(true)
  const [selectedImages, setSelectedImages] = useState<string[]>([])
  const [selectedColor, setSelectedColor] = useState("#f08bf0")
  const [error, setError] = useState("")

  // Handle image upload
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files) return

    // Check if we already have enough images
    if (selectedImages.length + files.length > 12) {
      setError("You can only upload up to 12 images")
      return
    }

    setError("")

    // Process each file
    Array.from(files).forEach((file) => {
      const reader = new FileReader()
      reader.onload = (e) => {
        if (e.target?.result) {
          setSelectedImages((prev) => [...prev, e.target!.result as string])
        }
      }
      reader.readAsDataURL(file)
    })
  }

  // Remove an image
  const removeImage = (index: number) => {
    setSelectedImages((prev) => prev.filter((_, i) => i !== index))
  }

  // Save the custom board
  const handleSave = () => {
    if (!boardName.trim()) {
      setError("Board name is required")
      return
    }

    if (selectedImages.length < 6) {
      setError("You need at least 6 images to create a board")
      return
    }

    const customBoard: CustomBoard = {
      id: `custom-${Date.now()}`,
      name: boardName,
      description: description || "Custom board",
      cardBack: `bg-[${selectedColor}]`,
      background: "bg-black",
      borderColor: `border-[${selectedColor}]`,
      isCustom: true,
      images: selectedImages,
      createdBy: "You", // In a real app, this would be the user's name or ID
      isPublic: isPublic,
      cardStyle: "object-cover w-full h-full",
    }

    onSave(customBoard)
  }

  return (
    <div className="w-full max-w-4xl mx-auto bg-black border border-[#7fdbff] border-opacity-30 rounded-lg p-6">
      <div className="flex items-center mb-6">
        <button onClick={onCancel} className="mr-4 text-[#7fdbff] hover:text-white transition-colors">
          <ArrowLeft size={20} />
        </button>
        <h2 className="text-2xl font-bold">
          <span className="text-[#f08bf0] drop-shadow-[0_0_8px_rgba(240,139,240,0.6)]">Create</span>{" "}
          <span className="text-[#7fdbff] drop-shadow-[0_0_8px_rgba(127,219,255,0.6)]">Custom Board</span>
        </h2>
      </div>

      {error && (
        <div className="bg-red-900/30 border border-red-500 text-red-200 px-4 py-2 rounded-md mb-4">{error}</div>
      )}

      <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
        <div>
          {/* Board Details */}
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-300 mb-1">Board Name</label>
            <input
              type="text"
              value={boardName}
              onChange={(e) => setBoardName(e.target.value)}
              className="w-full bg-black border border-gray-700 rounded-md px-3 py-2 focus:outline-none focus:border-[#7fdbff]"
              placeholder="My Custom Board"
            />
          </div>

          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-300 mb-1">Description</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full bg-black border border-gray-700 rounded-md px-3 py-2 focus:outline-none focus:border-[#7fdbff]"
              placeholder="Describe your board..."
              rows={3}
            />
          </div>

          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-300 mb-1">Card Back Color</label>
            <div className="flex items-center">
              <input
                type="color"
                value={selectedColor}
                onChange={(e) => setSelectedColor(e.target.value)}
                className="w-10 h-10 rounded-md border-0 p-0 mr-3"
              />
              <div
                className="w-12 h-12 rounded-md flex items-center justify-center text-black font-bold"
                style={{ backgroundColor: selectedColor }}
              >
                ?
              </div>
            </div>
          </div>

          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-300 mb-1">Visibility</label>
            <div className="flex space-x-4">
              <button
                className={`flex items-center px-4 py-2 rounded-full ${
                  isPublic
                    ? "bg-[#7fdbff] text-black shadow-[0_0_15px_rgba(127,219,255,0.4)]"
                    : "bg-transparent border border-gray-700 text-gray-300"
                }`}
                onClick={() => setIsPublic(true)}
              >
                <Globe size={16} className="mr-2" />
                Public
              </button>
              <button
                className={`flex items-center px-4 py-2 rounded-full ${
                  !isPublic
                    ? "bg-[#f08bf0] text-black shadow-[0_0_15px_rgba(240,139,240,0.4)]"
                    : "bg-transparent border border-gray-700 text-gray-300"
                }`}
                onClick={() => setIsPublic(false)}
              >
                <Lock size={16} className="mr-2" />
                Private
              </button>
            </div>
          </div>
        </div>

        <div>
          {/* Image Upload */}
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-300 mb-1">
              Upload Images ({selectedImages.length}/12)
            </label>
            <p className="text-xs text-gray-400 mb-2">
              Upload at least 6 images for your memory cards. Each image will be used as a pair.
            </p>

            <label className="block w-full border-2 border-dashed border-gray-700 rounded-lg p-4 text-center cursor-pointer hover:border-[#7fdbff] transition-all">
              <Upload className="mx-auto text-gray-400 mb-2" />
              <span className="text-gray-400">Click to upload images</span>
              <input type="file" multiple accept="image/*" className="hidden" onChange={handleImageUpload} />
            </label>
          </div>

          {/* Image Preview */}
          {selectedImages.length > 0 && (
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Selected Images</label>
              <div className="grid grid-cols-3 gap-2 max-h-60 overflow-y-auto p-1">
                {selectedImages.map((image, index) => (
                  <div key={index} className="relative group">
                    <img
                      src={image || "/placeholder.svg"}
                      alt={`Card ${index + 1}`}
                      className="w-full h-20 object-cover rounded-md"
                    />
                    <button
                      className="absolute top-1 right-1 bg-black bg-opacity-70 rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                      onClick={() => removeImage(index)}
                    >
                      <X size={14} className="text-white" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex justify-end space-x-4 mt-6">
        <button
          className="px-4 py-2 border border-gray-700 rounded-md text-gray-300 hover:border-[#7fdbff] transition-colors"
          onClick={onCancel}
        >
          Cancel
        </button>
        <button
          className="bg-[#f08bf0] hover:bg-[#f08bf0]/80 text-white px-6 py-2 rounded-md font-bold transition-all duration-300 hover:scale-105 shadow-[0_0_15px_rgba(240,139,240,0.4)]"
          onClick={handleSave}
        >
          Save Board
        </button>
      </div>
    </div>
  )
}

