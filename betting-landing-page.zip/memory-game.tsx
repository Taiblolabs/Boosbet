"use client"

import { useState, useEffect } from "react"
import { Menu, X, ArrowLeft, Trophy, Timer, RefreshCw, Twitter, Instagram } from "lucide-react"
import Link from "next/link"

// Card type
interface Card {
  id: number
  emoji: string
  isFlipped: boolean
  isMatched: boolean
}

export default function MemoryGame() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [cards, setCards] = useState<Card[]>([])
  const [flippedCards, setFlippedCards] = useState<number[]>([])
  const [matchedPairs, setMatchedPairs] = useState(0)
  const [moves, setMoves] = useState(0)
  const [gameStarted, setGameStarted] = useState(false)
  const [gameCompleted, setGameCompleted] = useState(false)
  const [timer, setTimer] = useState(0)
  const [timerInterval, setTimerInterval] = useState<NodeJS.Timeout | null>(null)

  // Emojis for the memory game
  const emojis = ["🎮", "🎲", "💰", "💎", "🏆", "🃏", "🎯", "🎪"]

  // Initialize game
  const initializeGame = () => {
    // Create pairs of cards with emojis
    const initialCards: Card[] = []
    emojis.forEach((emoji, index) => {
      // Create two cards with the same emoji (a pair)
      initialCards.push({
        id: index * 2,
        emoji,
        isFlipped: false,
        isMatched: false,
      })
      initialCards.push({
        id: index * 2 + 1,
        emoji,
        isFlipped: false,
        isMatched: false,
      })
    })

    // Shuffle the cards
    const shuffledCards = [...initialCards].sort(() => Math.random() - 0.5)
    setCards(shuffledCards)
    setFlippedCards([])
    setMatchedPairs(0)
    setMoves(0)
    setGameCompleted(false)
    setTimer(0)

    // Clear any existing timer
    if (timerInterval) {
      clearInterval(timerInterval)
      setTimerInterval(null)
    }

    setGameStarted(false)
  }

  // Start the game timer
  const startTimer = () => {
    if (timerInterval) return

    const interval = setInterval(() => {
      setTimer((prevTimer) => prevTimer + 1)
    }, 1000)

    setTimerInterval(interval)
  }

  // Handle card click
  const handleCardClick = (cardId: number) => {
    // Start the game and timer on first card click
    if (!gameStarted) {
      setGameStarted(true)
      startTimer()
    }

    // Ignore clicks if game is completed or if two cards are already flipped
    if (gameCompleted || flippedCards.length >= 2) return

    // Find the clicked card
    const clickedCard = cards.find((card) => card.id === cardId)

    // Ignore if card is already flipped or matched
    if (!clickedCard || clickedCard.isFlipped || clickedCard.isMatched) return

    // Flip the card
    const updatedCards = cards.map((card) => (card.id === cardId ? { ...card, isFlipped: true } : card))
    setCards(updatedCards)

    // Add card to flipped cards
    const updatedFlippedCards = [...flippedCards, cardId]
    setFlippedCards(updatedFlippedCards)

    // If two cards are flipped, check for a match
    if (updatedFlippedCards.length === 2) {
      setMoves((prevMoves) => prevMoves + 1)

      const [firstCardId, secondCardId] = updatedFlippedCards
      const firstCard = updatedCards.find((card) => card.id === firstCardId)
      const secondCard = updatedCards.find((card) => card.id === secondCardId)

      if (firstCard && secondCard && firstCard.emoji === secondCard.emoji) {
        // Match found
        setTimeout(() => {
          const matchedCards = updatedCards.map((card) =>
            card.id === firstCardId || card.id === secondCardId ? { ...card, isMatched: true } : card,
          )
          setCards(matchedCards)
          setFlippedCards([])
          setMatchedPairs((prevMatchedPairs) => {
            const newMatchedPairs = prevMatchedPairs + 1
            // Check if all pairs are matched
            if (newMatchedPairs === emojis.length) {
              setGameCompleted(true)
              if (timerInterval) {
                clearInterval(timerInterval)
                setTimerInterval(null)
              }
            }
            return newMatchedPairs
          })
        }, 500)
      } else {
        // No match, flip cards back
        setTimeout(() => {
          const resetCards = updatedCards.map((card) =>
            card.id === firstCardId || card.id === secondCardId ? { ...card, isFlipped: false } : card,
          )
          setCards(resetCards)
          setFlippedCards([])
        }, 1000)
      }
    }
  }

  // Format time for display (mm:ss)
  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60)
    const remainingSeconds = seconds % 60
    return `${minutes.toString().padStart(2, "0")}:${remainingSeconds.toString().padStart(2, "0")}`
  }

  // Initialize game on component mount
  useEffect(() => {
    initializeGame()

    // Clean up timer on unmount
    return () => {
      if (timerInterval) {
        clearInterval(timerInterval)
      }
    }
  }, [])

  return (
    <div className="min-h-screen bg-black text-white font-['Quicksand']">
      {/* Header */}
      <header className="bg-black sticky top-0 z-50 shadow-md border-b border-[#7fdbff] border-opacity-30">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="text-2xl md:text-3xl font-['Quicksand'] text-white font-bold relative">
            <Link href="/">
              <span className="text-[#f08bf0] drop-shadow-[0_0_8px_rgba(240,139,240,0.6)]">Boo</span>
              <span className="text-[#7fdbff] drop-shadow-[0_0_8px_rgba(127,219,255,0.6)]">Bets</span>
              <div className="absolute -bottom-1 left-0 w-full h-[2px] bg-gradient-to-r from-[#f08bf0] to-[#7fdbff]"></div>
            </Link>
          </div>

          {/* Mobile menu button */}
          <button className="md:hidden text-white" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X size={24} className="text-[#7fdbff]" /> : <Menu size={24} className="text-[#7fdbff]" />}
          </button>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/" className="text-white hover:text-[#7fdbff] transition-colors duration-300 relative group">
              Home
              <span className="absolute -bottom-1 left-0 w-0 h-[2px] bg-[#7fdbff] group-hover:w-full transition-all duration-300"></span>
            </Link>
            <Link
              href="/games-page"
              className="text-white hover:text-[#7fdbff] transition-colors duration-300 relative group"
            >
              Games
              <span className="absolute -bottom-1 left-0 w-0 h-[2px] bg-[#7fdbff] group-hover:w-full transition-all duration-300"></span>
            </Link>
            <Link href="#" className="text-white hover:text-[#7fdbff] transition-colors duration-300 relative group">
              Content
              <span className="absolute -bottom-1 left-0 w-0 h-[2px] bg-[#7fdbff] group-hover:w-full transition-all duration-300"></span>
            </Link>
            <Link href="#" className="text-white hover:text-[#7fdbff] transition-colors duration-300 relative group">
              Register
              <span className="absolute -bottom-1 left-0 w-0 h-[2px] bg-[#7fdbff] group-hover:w-full transition-all duration-300"></span>
            </Link>
            <Link href="#" className="text-white hover:text-[#7fdbff] transition-colors duration-300 relative group">
              Login
              <span className="absolute -bottom-1 left-0 w-0 h-[2px] bg-[#7fdbff] group-hover:w-full transition-all duration-300"></span>
            </Link>
            <button className="bg-[#f08bf0] hover:bg-[#f08bf0]/80 text-white px-4 py-2 rounded-full transition-all duration-300 hover:scale-105 shadow-[0_0_15px_rgba(240,139,240,0.4)] hover:shadow-[0_0_20px_rgba(240,139,240,0.5)]">
              Join Now
            </button>
          </nav>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden bg-black py-4 px-4 absolute w-full border-b border-[#7fdbff] border-opacity-30">
            <nav className="flex flex-col space-y-4">
              <Link href="/" className="text-white hover:text-[#7fdbff] transition-colors duration-300">
                Home
              </Link>
              <Link href="/games-page" className="text-white hover:text-[#7fdbff] transition-colors duration-300">
                Games
              </Link>
              <Link href="#" className="text-white hover:text-[#7fdbff] transition-colors duration-300">
                Content
              </Link>
              <Link href="#" className="text-white hover:text-[#7fdbff] transition-colors duration-300">
                Register
              </Link>
              <Link href="#" className="text-white hover:text-[#7fdbff] transition-colors duration-300">
                Login
              </Link>
              <button className="bg-[#f08bf0] hover:bg-[#f08bf0]/80 text-white px-4 py-2 rounded-full transition-transform duration-300 hover:scale-105 w-full shadow-[0_0_15px_rgba(240,139,240,0.4)]">
                Join Now
              </button>
            </nav>
          </div>
        )}
      </header>

      {/* Game Section */}
      <section className="relative py-8 bg-black overflow-hidden">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxwYXR0ZXJuIGlkPSJncmlkIiB3aWR0aD0iODAiIGhlaWdodD0iODAiIHBhdHRlcm5Vbml0cz0idXNlclNwYWNlT25Vc2UiPjxwYXRoIGQ9Ik0gODAgMCBMIDAgMCAwIDgwIiBmaWxsPSJub25lIiBzdHJva2U9IiMwZmYiIHN0cm9rZS13aWR0aD0iMC41IiBzdHJva2Utb3BhY2l0eT0iMC4xIi8+PC9wYXR0ZXJuPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZ3JpZCkiLz48L3N2Zz4=')] opacity-30"></div>

        {/* Animated circles */}
        <div className="absolute -bottom-20 -left-20 w-60 h-60 bg-[#f08bf0] rounded-full filter blur-[100px] opacity-20 animate-pulse"></div>
        <div
          className="absolute -top-20 -right-20 w-60 h-60 bg-[#7fdbff] rounded-full filter blur-[100px] opacity-20 animate-pulse"
          style={{ animationDelay: "1s" }}
        ></div>

        <div className="container mx-auto px-4 relative z-10">
          {/* Back to Games button */}
          <div className="mb-6">
            <Link
              href="/games-page"
              className="inline-flex items-center text-[#7fdbff] hover:text-white transition-colors duration-300"
            >
              <ArrowLeft size={20} className="mr-2" />
              Back to Games
            </Link>
          </div>

          {/* Game Title */}
          <div className="text-center mb-8">
            <h1 className="text-3xl md:text-4xl font-bold mb-2">
              <span className="text-[#f08bf0] drop-shadow-[0_0_8px_rgba(240,139,240,0.6)]">Memory</span>{" "}
              <span className="text-[#7fdbff] drop-shadow-[0_0_8px_rgba(127,219,255,0.6)]">Game</span>
            </h1>
            <p className="text-gray-300">Match pairs of cards to win. Click on a card to flip it.</p>
          </div>

          {/* Game Stats */}
          <div className="flex justify-center gap-6 mb-6">
            <div className="flex items-center bg-black border border-[#7fdbff] border-opacity-30 rounded-full px-4 py-2">
              <Trophy className="text-[#f08bf0] mr-2" size={18} />
              <span>
                Pairs: {matchedPairs}/{emojis.length}
              </span>
            </div>
            <div className="flex items-center bg-black border border-[#7fdbff] border-opacity-30 rounded-full px-4 py-2">
              <Timer className="text-[#7fdbff] mr-2" size={18} />
              <span>Time: {formatTime(timer)}</span>
            </div>
            <div className="flex items-center bg-black border border-[#7fdbff] border-opacity-30 rounded-full px-4 py-2">
              <span>Moves: {moves}</span>
            </div>
          </div>

          {/* Game Board */}
          <div className="max-w-2xl mx-auto mb-8">
            <div className="grid grid-cols-4 gap-3">
              {cards.map((card) => (
                <div
                  key={card.id}
                  onClick={() => handleCardClick(card.id)}
                  className={`aspect-square flex items-center justify-center rounded-lg cursor-pointer transition-all duration-300 transform ${
                    card.isFlipped || card.isMatched
                      ? "bg-black border-2 border-[#f08bf0] shadow-[0_0_15px_rgba(240,139,240,0.4)]"
                      : "bg-gradient-to-br from-[#7fdbff] to-[#f08bf0] hover:scale-105"
                  } ${card.isMatched ? "opacity-70" : "opacity-100"}`}
                >
                  {card.isFlipped || card.isMatched ? (
                    <span className="text-4xl">{card.emoji}</span>
                  ) : (
                    <span className="text-2xl text-black font-bold">?</span>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Game Controls */}
          <div className="flex justify-center mb-8">
            <button
              onClick={initializeGame}
              className="flex items-center bg-[#f08bf0] hover:bg-[#f08bf0]/80 text-white px-6 py-3 rounded-full font-bold transition-all duration-300 hover:scale-105 shadow-[0_0_15px_rgba(240,139,240,0.4)]"
            >
              <RefreshCw size={18} className="mr-2" />
              Restart Game
            </button>
          </div>

          {/* Game Completion Message */}
          {gameCompleted && (
            <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50">
              <div className="bg-black border-2 border-[#7fdbff] rounded-lg p-8 max-w-md text-center shadow-[0_0_30px_rgba(127,219,255,0.5)]">
                <div className="text-6xl mb-4">🎉</div>
                <h2 className="text-2xl font-bold mb-2 text-[#7fdbff]">Congratulations!</h2>
                <p className="text-gray-300 mb-4">You completed the memory game!</p>
                <div className="flex justify-center gap-4 mb-6">
                  <div className="text-center">
                    <div className="text-xl font-bold text-[#f08bf0]">{moves}</div>
                    <div className="text-sm text-gray-400">Moves</div>
                  </div>
                  <div className="text-center">
                    <div className="text-xl font-bold text-[#f08bf0]">{formatTime(timer)}</div>
                    <div className="text-sm text-gray-400">Time</div>
                  </div>
                </div>
                <button
                  onClick={initializeGame}
                  className="bg-[#f08bf0] hover:bg-[#f08bf0]/80 text-white px-6 py-3 rounded-full font-bold transition-all duration-300 hover:scale-105 shadow-[0_0_15px_rgba(240,139,240,0.4)]"
                >
                  Play Again
                </button>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black py-8 border-t border-[#7fdbff] border-opacity-30">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="text-xl font-['Quicksand'] font-bold mb-4 md:mb-0 relative">
              <span className="text-[#f08bf0] drop-shadow-[0_0_8px_rgba(240,139,240,0.6)]">Boo</span>
              <span className="text-[#7fdbff] drop-shadow-[0_0_8px_rgba(127,219,255,0.6)]">Bets</span>
              <div className="absolute -bottom-1 left-0 w-full h-[2px] bg-gradient-to-r from-[#f08bf0] to-[#7fdbff]"></div>
            </div>
            <div className="flex space-x-6 mb-4 md:mb-0">
              <Link
                href="#"
                className="text-gray-400 hover:text-[#7fdbff] transition-colors duration-300 relative group"
              >
                Terms
                <span className="absolute -bottom-1 left-0 w-0 h-[1px] bg-[#7fdbff] group-hover:w-full transition-all duration-300"></span>
              </Link>
              <Link
                href="#"
                className="text-gray-400 hover:text-[#7fdbff] transition-colors duration-300 relative group"
              >
                Privacy
                <span className="absolute -bottom-1 left-0 w-0 h-[1px] bg-[#7fdbff] group-hover:w-full transition-all duration-300"></span>
              </Link>
              <Link
                href="#"
                className="text-gray-400 hover:text-[#7fdbff] transition-colors duration-300 relative group"
              >
                Contact
                <span className="absolute -bottom-1 left-0 w-0 h-[1px] bg-[#7fdbff] group-hover:w-full transition-all duration-300"></span>
              </Link>
            </div>
            <div className="flex space-x-4">
              <Link
                href="#"
                className="text-gray-400 hover:text-[#7fdbff] transition-all duration-300 transform hover:scale-110"
              >
                <Twitter size={20} className="hover:drop-shadow-[0_0_8px_rgba(127,219,255,0.6)]" />
              </Link>
              <Link
                href="#"
                className="text-gray-400 hover:text-[#f08bf0] transition-all duration-300 transform hover:scale-110"
              >
                <Instagram size={20} className="hover:drop-shadow-[0_0_8px_rgba(240,139,240,0.6)]" />
              </Link>
            </div>
          </div>
          <div className="mt-8 text-center text-gray-500 text-sm">
            &copy; {new Date().getFullYear()} BooBets. All rights reserved. For adults 18+ only.
          </div>
        </div>
      </footer>
    </div>
  )
}

